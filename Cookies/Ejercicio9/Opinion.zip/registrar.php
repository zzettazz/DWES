<h1>NUEVO USUARIO</h1>
<br/>
<form action="registarNuevoUsuario.php" method="GET">
    Usuario <input type="text" id="usuarioRegistro" name="usuarioRegistro"/><br/>
    Contraseña <input type="password" id="contraseniaRegistro" name="contraseniaRegistro"><br/>
    <input type="submit"/>
</form>
<br/>
<br/>
<a href="login.php">Volver a login</a>